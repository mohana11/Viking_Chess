
public abstract class ConcretePiece implements Piece{

    public Player getOwner() {
        return null;
    }


    public String getType() {
        return null;
    }
}
